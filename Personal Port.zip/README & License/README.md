<div align="center">
    <a href="https://github.com/joeguy57/PersonalPortfolio">
        <img src="mainLogo.png" alt="Personal Port">
    </a>
</div>

<h1 align="center">Personal Portfolio</h1>

<p align="center">
   This Project was created to showcase my github repository and any other projects that 
    I have had the privilege of working on. It is created for the potential of backing up my resume.
    <br>
    <a href="https://github.com/joeguy57/PersonalPortfolio/issues">Report bug</a>
    ·
    <a href="https://github.com/joeguy57/PersonalPortfolio/issues">Request feature</a>
</p>

## Table Of Contents
- [Status](#status)
- [What's Included](#whats-included)
- [Bugs and Feature Requests](#bugs-and-feature-requests)
- [Creator](#creator)
- [Thanks](#thanks)
- [Copyright and License](#copyright-and-license)

## Status
This Project is currently in progress and is on its first days of being done.

## What's Included
- About Me
- My Work

## Bugs and Feature Requests
- None so far

## Creator
<div align="center">
    <a href="https://github.com/joeguy57">  
        <img src="https://avatars.githubusercontent.com/u/56702275?s=400&u=026c4c9ee2a9450b09d8a7605644dd1161b1d91b&v=4" alt="drawing" width="100"/>  
    </a>
    <p>Joseph Menezes</p>
</div>

## Thanks
Thank you for taking the time to go through my portfolio.
<div>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;<a href="https://github.com/joeguy57"><span><img style="background: transparent;" src="githubLogo.png" width = 100px alt="GitHub Logo"></span></a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span><a href="https://www.linkedin.com/in/joseph-menezes/"><img style="background: transparent;" src="linkedInLogo.png" width = 75px alt="LinkedIn Logo"></a></span></div>

## Copyright and License
Code and documentation copyright the authors. Code released under the [GNU GENERAL PUBLIC LICENSE](LICENSE).
